echo "@ARMPHACKS"


clear
ARMP=$(head -3 /dev/urandom | tr -cd 'a-z0-9' | cut -c -16)

echo GL RESET

XNXXARMP=$(grep -n com.tencent.ig /data/system/users/0/settings_ssaid.xml | grep -o 'value="[a-zA-Z0-9]*"*' | cut -d '"' -f2)
sed -i "s/$XNXXARMP/$ARMP/g" /data/system/users/0/settings_ssaid.xml

echo KR RESET

PORNHUBARMP=$(grep -n com.pubg.krmobile /data/system/users/0/settings_ssaid.xml | grep -o 'value="[a-zA-Z0-9]*"*' | cut -d '"' -f2)
sed -i "s/$PORNHUBARMP/$ARMP/g" /data/system/users/0/settings_ssaid.xml

echo VNG RESET

XVIDEOSARMP=$(grep -n com.vng.pubgmobile /data/system/users/0/settings_ssaid.xml | grep -o 'value="[a-zA-Z0-9]*"*' | cut -d '"' -f2)
sed -i "s/$XVIDEOSARMP/$ARMP/g" /data/system/users/0/settings_ssaid.xml

echo TW RESET

XHAMSTERARMP=$(grep -n com.rekoo.pubgm /data/system/users/0/settings_ssaid.xml | grep -o 'value="[a-zA-Z0-9]*"*' | cut -d '"' -f2)
sed -i "s/$XHAMSTERARMP/$ARMP/g" /data/system/users/0/settings_ssaid.xml

echo BGMI RESET

PORNHOTARMP=$(grep -n com.pubg.imobile /data/system/users/0/settings_ssaid.xml | grep -o 'value="[a-zA-Z0-9]*"*' | cut -d '"' -f2)
sed -i "s/$PORNHOTARMP/$ARMP/g" /data/system/users/0/settings_ssaid.xml

echo DONE REBOOTING.....

su -c reboot