GL="com.tencent.ig"

am force-stop $GL
clear
rm -rf /data/data/$GL/shared_prefs /storage/emulated/0/Documents/
mkdir /data/data/$GL/shared_prefs
chmod 777 /data/data/$GL/shared_prefs
rm -rf /data/data/$GL/files

GUEST="/data/data/$GL/shared_prefs/device_id.xml"
rm -rf $GUEST
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $GUEST
rm -rf /data/data/$GL/databases
rm -rf /data/media/0/Android/data/$GL/files/login-identifier.txt
rm -rf /data/media/0/Android/data/$GL/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /data/media/0/Android/data/$GL/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /data/media/0/Android/data/$GL/files/TGPA
touch /data/media/0/Android/data/$GL/files/TGPA
rm -rf /data/media/0/Android/data/$GL/files/ProgramBinaryCache
touch /data/media/0/Android/data/$GL/files/ProgramBinaryCache
iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT
KR="com.pubg.krmobile"

am force-stop $KR
clear
rm -rf /data/data/$KR/shared_prefs /storage/emulated/0/Documents/
mkdir /data/data/$KR/shared_prefs
chmod 777 /data/data/$KR/shared_prefs
rm -rf /data/data/$KR/files

GUEST="/data/data/$KR/shared_prefs/device_id.xml"
rm -rf $GUEST
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $GUEST
rm -rf /data/data/$KR/databases
rm -rf /data/media/0/Android/data/$KR/files/login-identifier.txt
rm -rf /data/media/0/Android/data/$KR/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /data/media/0/Android/data/$KR/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /data/media/0/Android/data/$KR/files/TGPA
touch /data/media/0/Android/data/$KR/files/TGPA
rm -rf /data/media/0/Android/data/$KR/files/ProgramBinaryCache
touch /data/media/0/Android/data/$KR/files/ProgramBinaryCache
iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT
KR="com.pubg.krmobile"

TW="com.rekoo.pubgm"

am force-stop $TW
clear
rm -rf /data/data/$TW/shared_prefs /storage/emulated/0/Documents/
mkdir /data/data/$TW/shared_prefs
chmod 777 /data/data/$TW/shared_prefs
rm -rf /data/data/$TW/files

GUEST="/data/data/$TW/shared_prefs/device_id.xml"
rm -rf $GUEST
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $GUEST
rm -rf /data/data/$TW/databases
rm -rf /data/media/0/Android/data/$TW/files/login-identifier.txt
rm -rf /data/media/0/Android/data/$TW/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /data/media/0/Android/data/$TW/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /data/media/0/Android/data/$TW/files/TGPA
touch /data/media/0/Android/data/$TW/files/TGPA
rm -rf /data/media/0/Android/data/$TW/files/ProgramBinaryCache
touch /data/media/0/Android/data/$TW/files/ProgramBinaryCache
iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT

TW="com.rekoo.pubgm"

am force-stop $TW
clear
rm -rf /data/data/$TW/shared_prefs /storage/emulated/0/Documents/
mkdir /data/data/$TW/shared_prefs
chmod 777 /data/data/$TW/shared_prefs
rm -rf /data/data/$TW/files

GUEST="/data/data/$TW/shared_prefs/device_id.xml"
rm -rf $GUEST
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $GUEST
rm -rf /data/data/$TW/databases
rm -rf /data/media/0/Android/data/$TW/files/login-identifier.txt
rm -rf /data/media/0/Android/data/$TW/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /data/media/0/Android/data/$TW/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /data/media/0/Android/data/$TW/files/TGPA
touch /data/media/0/Android/data/$TW/files/TGPA
rm -rf /data/media/0/Android/data/$TW/files/ProgramBinaryCache
touch /data/media/0/Android/data/$TW/files/ProgramBinaryCache
iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT

BETA="com.tencent.igce"

am force-stop $BETA
clear
rm -rf /data/data/$BETA/shared_prefs /storage/emulated/0/Documents/
mkdir /data/data/$BETA/shared_prefs
chmod 777 /data/data/$BETA/shared_prefs
rm -rf /data/data/$BETA/files

GUEST="/data/data/$BETA/shared_prefs/device_id.xml"
rm -rf $GUEST
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
    <string name=\"random\"></string>
    <string name=\"install\"></string>
    <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > $GUEST
rm -rf /data/data/$BETA/databases
rm -rf /data/media/0/Android/data/$BETA/files/login-identifier.txt
rm -rf /data/media/0/Android/data/$BETA/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /data/media/0/Android/data/$BETA/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /data/media/0/Android/data/$BETA/files/TGPA
touch /data/media/0/Android/data/$BETA/files/TGPA
rm -rf /data/media/0/Android/data/$BETA/files/ProgramBinaryCache
touch /data/media/0/Android/data/$BETA/files/ProgramBinaryCache
iptables -I OUTPUT -d cloud.vmp.onezapp.com -j REJECT
iptables -I INPUT -s cloud.vmp.onezapp.com -j REJECT